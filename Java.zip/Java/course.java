
/**
 * Write a description of class s here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class course{

    // instance variables - replace the example below with your own
    private String CourseID;
    private String CourseName;
    private int  Duration;
    public String CourseLeader;
    //method of creating constructor 
    public course(String CourseID, String CourseName, int Duration)
    {
        // initialise instance variables
        this.CourseID=CourseID;
        this.CourseName=CourseName;
        this.Duration=Duration;
        this.CourseLeader=""; //empty string("")in the constructor
    } 
    //creating a get method of attributes
    public String getCourseID(){
        return CourseID;
    }
    
    public String getCourseName(){
        return CourseName;
        }
        
    public int getDuration(){
         return Duration;      
     }
     
    public String getCourseLeader(){
         return CourseLeader;
     }
     //creating a set method of CourseLeader
    public void setCourseLeader(String CourseLeader) {
        this.CourseLeader = CourseLeader;
    }
    //creating the method of display
    public void Display(){
        System.out.println("ID of Course: "+CourseID);
        System.out.println("Name of Course: "+CourseName);
        System.out.println("Duration of Course: "+Duration);
        System.out.println("Course Leader :" + getCourseLeader());
        //condition making
    }
    }
    
