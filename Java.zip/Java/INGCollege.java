
/**
 * Write a description of class s here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.JFrame;
import java.util.ArrayList;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class INGCollege{
    private JFrame window;
    private JPanel mainPanel, panel1, panel2;
    private JLabel mainLabel,
    //labelling academicCourse 
    acCourseID,acCourseName,acDuration, acLevel, acCredit, acNumberOfAssessments,acCourseLeader,acLecturerName,acStartingDate,acCompletionDate; 
    //mainPanel Button
    private JButton academicButton, nonAcademicButton;
    //button of academic course
    private JButton academicReturn,btnAddacademicCourse,btnAcRegister, btnAcDisplay ,btnAcClear; 
    //textfields of academic course 
    private JTextField textAcCourseID,textAcCourseName,textAcDuration,textAcLevel,textAcCredit,textAcNumOfAssessment,textAcCourseLeader,
    textAcLecturerName,textAcStartingDate,textAcCompletionDate  ;
    //labelling non-academic course
    private JLabel nacCourseID, nacCourseName, nacDuration, nacPrerequisite,nacCourseLeader,nacInstructorName,nacStartDate, nacCompletion,nacExam ;
    //textfields of non-academic course
    private JTextField textNacCourseID, textNacCourseName, textNacDuration,textNacPrerequisite,textNacCourseLeader,textNacInstructor,textNacStart,
    textNacCompletion,textNacExam;
    //button of non academic Course
    private JButton btnAddNonAC,btnNacRegister,btnNacRemove,btnNacDisplay, btnNacClear;
    private ArrayList<course>list= new ArrayList<course>();
    
    public INGCollege(){
        initializeFrame();
        initializeMainPanel();
    }
    
    public void initializeFrame(){
        window= new JFrame("Courses");
        window.setSize(700,700);
        window.setLayout(null);
        window.setResizable(false);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);
        }
        
    public void initializeMainPanel(){
        mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setSize(700,700);
        window.add(mainPanel);
        //setting up the background color of the main panel
        mainPanel.setBackground(Color.lightGray);
        
        //creating label for courses 
        mainLabel= new JLabel("Types of courses you can choose: ");
        mainLabel.setBounds(40,30,375,35);
        mainPanel.add(mainLabel);
        
        //Creating button for selecting academic course
        academicButton = new JButton("Academic Course");
        academicButton.setBounds(50,75,180,35);
        academicButton.setLayout(new FlowLayout());
        mainPanel.add(academicButton);
        
        //adding action listener to the Academic Course
        academicButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                panel1();
                mainPanel.setVisible(false);
                
            }
        });
        
        //Creating button for selecting non academic course
        nonAcademicButton = new JButton("Non Academic Course");
        nonAcademicButton.setBounds(250,75,180,35);
        nonAcademicButton.setLayout(new FlowLayout());
        mainPanel.add(nonAcademicButton);
        
        //adding action Listener to the non academic course
        nonAcademicButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                panel2();
                mainPanel.setVisible(false);
            }
        });
        
        mainPanel.setVisible(true);
    }
        
        public void panel1(){
        //creating and initializing panel1 inside the main panel
        JPanel panel1= new JPanel();
        window.add(panel1);
        panel1.setLayout(null);
        panel1.setBounds(0,0,750,950);
        panel1.setBackground(Color. WHITE);

        //creation of Return button to return the main panel
        JButton academicReturn= new JButton(" Return ");
        academicReturn.setBounds(450,540,150,30);
        panel1.add(academicReturn);
        
        // adding action listenerto Return button of academic course's panel; panel1
        academicReturn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                panel1.setVisible(false);
                mainPanel.setVisible(true);
            }
        });
        
        //labels of courseID 
        acCourseID = new JLabel("Course ID: ");
        acCourseID.setBounds(10,40,230,30);
        panel1.add(acCourseID);
        
        //textfields of entry of the CourseID
        textAcCourseID  = new JTextField();
        textAcCourseID .setBounds(150,40,230,30);
        panel1.add(textAcCourseID );
        
        //labels of Course Name
        acCourseName = new JLabel("Course Name: ");
        acCourseName.setBounds(10,80,230,30);
        panel1.add(acCourseName);
        
        //textfields of entry of the Course Name 
        textAcCourseName =  new JTextField();
        textAcCourseName .setBounds(150,80,230,30);
        panel1.add(textAcCourseName );
        
        //labels of Duration 
        acDuration = new JLabel("Duration: ");
        acDuration.setBounds(10,120,230,30);
        panel1.add(acDuration);
        
        //textFields of Duration
        textAcDuration = new JTextField();
        textAcDuration.setBounds(150,120,230,30);
        panel1.add(textAcDuration);
        
        //label of Level
        acLevel =  new JLabel("Level: ");
        acLevel.setBounds(10,160,230,30);
        panel1.add(acLevel);
        
        //textfields of Level
        textAcLevel = new JTextField();
        textAcLevel.setBounds(150,160,230,30);
        panel1.add(textAcLevel);
        
        //label of Credit
        acCredit = new JLabel("Credit: ");
        acCredit.setBounds(10,200,230,30);
        panel1.add(acCredit);
        
        //textField of Credit 
        textAcCredit = new JTextField();
        textAcCredit .setBounds(150,200,230,30);
        panel1.add(textAcCredit );
        
        //label of Number of Assessments
        acNumberOfAssessments = new JLabel("Number Of Assessments: ");
        acNumberOfAssessments.setBounds(10,240,230,30);
        panel1.add(acNumberOfAssessments);
        
        //textField of number of Assessments
        textAcNumOfAssessment = new JTextField();
        textAcNumOfAssessment.setBounds(160,240,230,30);
        panel1.add(textAcNumOfAssessment);
        
        //buttons of adding Academic Course
        JButton btnAddacademicCourse = new JButton("Add Academic Course");
        btnAddacademicCourse.setBounds(150,280,230,30);
        panel1.add(btnAddacademicCourse);
        // adding action listener to Add Academic Course Button 
        btnAddacademicCourse.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ae){
                    AcademicCourse();
                }
        });
        
        //label of Course Leader
        acCourseLeader = new JLabel("Course Leader: ");
        acCourseLeader.setBounds(10,320,230,30);
        panel1.add(acCourseLeader);
        
        //textField of Course Leader
        textAcCourseLeader = new JTextField();
        textAcCourseLeader.setBounds(150,320,230,30);
        panel1.add(textAcCourseLeader);
        
        //label of Lecturer Name
        acLecturerName = new JLabel("Lecturer Name: ");
        acLecturerName.setBounds(10,360,230,30);
        panel1.add(acLecturerName);
        
        //textfield of Lecturer Name 
        textAcLecturerName = new JTextField();
        textAcLecturerName.setBounds(150,360,230,30);
        panel1.add(textAcLecturerName);
        
        //label of starting Date
        acStartingDate = new JLabel("Starting Date: ");
        acStartingDate.setBounds(10,400,230,30);
        panel1.add(acStartingDate);
        
        //textField of starting Date
        textAcStartingDate = new JTextField();
        textAcStartingDate.setBounds(150,400,230,30);
        panel1.add(textAcStartingDate);
        
        //label of Completion Date
        acCompletionDate = new JLabel("Completion Date: ");
        acCompletionDate.setBounds(10,440,230,30);
        panel1.add(acCompletionDate);
        
        //textField of Completion Date
        textAcCompletionDate = new JTextField();
        textAcCompletionDate.setBounds(150,440,230,30);
        panel1.add(textAcCompletionDate );
        
        //butttons to register AcademicCourse
        btnAcRegister = new JButton("Register");
        btnAcRegister.setBounds(150,480,130,35);
        panel1.add(btnAcRegister);
        btnAcRegister.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ae){
                    acRegister();
                }
            });
            
        //buttons for displaying Academic Course
        btnAcDisplay= new JButton("Display");
        btnAcDisplay.setBounds(390,440,80,35);
        panel1.add(btnAcDisplay);
        btnAcDisplay.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ae){
                    acDisplay();
                };
            });
            
        
        //button for clearing Academic Course 
        btnAcClear= new JButton("Clear");
        btnAcClear.setBounds(150,520,80,30);
        panel1.add(btnAcClear);
        btnAcClear.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ae){
                    acClear();
                };
            });

    }
    
    public void AcademicCourse(){
        String acCourseID = textAcCourseID.getText();
        String acCourseName = textAcCourseName.getText();
        String acDuration = textAcDuration.getText();
        String acLevel = textAcLevel.getText();
        String acCredit =  textAcCredit.getText();
        String acNumberOfAssessments = textAcNumOfAssessment.getText();
        int Duration, NumberOfAssessments,Credit;

        if(acCourseID.trim().equals("") || acCourseName.trim().equals("") || acDuration.trim().equals("") || acLevel.trim().equals("") || acCredit.trim().equals("") || acNumberOfAssessments.trim().equals("")){
            JOptionPane.showMessageDialog(window,"Some forms are unfilled so, please fill all the forms -_-","Error" ,0);
        }
        else{
            try{
                Duration = Integer.parseInt(acDuration);
                NumberOfAssessments= Integer.parseInt(acNumberOfAssessments);
                Credit = Integer.parseInt(acCredit);
            }catch(NumberFormatException nfe){
                JOptionPane.showMessageDialog(window,"Please enter data in correct format (-_-)" ,"Error",0);
                return;
            }
            for(course c : list){
                if (c instanceof AcademicCourse){
                    AcademicCourse ac = (AcademicCourse) c;
                    if(ac.getCourseID()==acCourseID){
                        JOptionPane.showMessageDialog(window,"Course ID already added (o_o)", "Error" ,0);
                        return;
                    }
                }
            }
            AcademicCourse acList= new AcademicCourse(acCourseID,acCourseName, Duration, acLevel, acCredit, NumberOfAssessments);
            list.add(acList);
            JOptionPane.showMessageDialog(window,"Academic Course is added successfully (^~^)","Info",1);
        }
    }
    
    public void acRegister(){
        String acCourseID = textAcCourseID.getText();
        String acCourseLeader = textAcCourseLeader.getText();
        String acLecturerName = textAcLecturerName.getText();
        String acStartingDate = textAcStartingDate.getText();
        String acCompletionDate = textAcCompletionDate.getText();
          if(acCourseID.trim().equals("") || acCourseLeader.trim().equals("") || acLecturerName.trim().equals("") || acStartingDate.trim().equals("")|| 
          acCompletionDate.trim().equals("")){
            JOptionPane.showMessageDialog(window,"Some forms are unfilled so, please fill all the forms -_-","Error",0);
          }
          else{
            boolean isRegistered = false;
            for(course c : list){
                if(c instanceof AcademicCourse){
                    AcademicCourse ac = (AcademicCourse) c;
                    if(ac.getCourseID()== acCourseID){
                        isRegistered = true;
                        if(ac.isRegistered == true)
                            JOptionPane.showMessageDialog(window,"This course is already registered (0_0)","Error",0);
                        }
                        else{
                            ac.Registered(acCourseLeader, acLecturerName, acStartingDate, acCompletionDate);
                            JOptionPane.showMessageDialog(window,"Academic Course Registered sucessfully (^_^)","Course Registered",1);
                            break;
                        }
                        if (isRegistered == false){
                        JOptionPane.showMessageDialog(window, " Course ID is not added, add the CourseID first" ,"Error",0);
                    }
                    }
            }
        }
    }

         public void acDisplay(){
        boolean rn = false;
        for(course c: list){
            if(c instanceof AcademicCourse){
                AcademicCourse ac = (AcademicCourse) c;
                rn = true;
                ac.Display();
            }
        }
        if(rn == false){
            JOptionPane.showMessageDialog(window,"Course id is not added (*_*)","Error",0);
        }
    }
    
    public void acClear(){
        int x= JOptionPane.showConfirmDialog(window,"Do you want to clear all the information of AcademicCourse?","Info",JOptionPane.YES_NO_OPTION);
        if(x==JOptionPane.YES_OPTION){
            JOptionPane.showMessageDialog(window,"Cleared","Info",(1));
            textAcCourseID.setText(null);
            textAcCourseName.setText(null);
            textAcDuration.setText(null);
            textAcLevel.setText(null);
            textAcCredit.setText(null);
            textAcNumOfAssessment.setText(null);
            textAcCourseLeader.setText(null);
            textAcLecturerName.setText(null);
            textAcStartingDate.setText(null);
            textAcCompletionDate.setText(null);

        }
    }
    
    public void panel2(){
        panel2= new JPanel();
        window.add(panel2);
        panel2.setLayout(null);
        panel2.setBounds(0,0,750,950);
        panel2.setBackground(Color.LIGHT_GRAY);
        
        JButton btnNacBack = new JButton("Return");
        btnNacBack.setBounds(450,580,100,30);
        panel2.add(btnNacBack);
        
        btnNacBack.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                panel2.setVisible(false);
                mainPanel.setVisible(true);
          }
       });
       
       //label of Non academic Course
       //label of course ID
        nacCourseID = new JLabel("CourseID : ");
        nacCourseID.setBounds(10,40,230,30);
        panel2.add(nacCourseID);

        //textfields of CourseID
        textNacCourseID = new JTextField();
        textNacCourseID.setBounds(150,40,230,30);
        panel2.add(textNacCourseID);

        //label of course Name
        nacCourseName = new JLabel("Course Name : ");
        nacCourseName .setBounds(10,80,230,30);
        panel2.add(nacCourseName );

        //textField of course Name
        textNacCourseName = new JTextField();
        textNacCourseName.setBounds(150,80,230,30);
        panel2.add(textNacCourseName);

       //label of duration
       nacDuration = new JLabel("Duration : ");
       nacDuration .setBounds(10,120,220,30);
       panel2.add(nacDuration);

       //textField of duration
       textNacDuration = new JTextField();
       textNacDuration.setBounds(150,120,220,30);
       panel2.add(textNacDuration);

       //label of prerequisite
       nacPrerequisite = new JLabel("Prerequisite : ");
       nacPrerequisite.setBounds(10,160,230,30);
       panel2.add(nacPrerequisite);

       //textField of prerequisite
       textNacPrerequisite = new JTextField();
       textNacPrerequisite.setBounds(150,160,230,30);
       panel2.add(textNacPrerequisite);
        
       //button of Non Academic Course
       btnAddNonAC = new JButton("Add Non Academic Course");
       btnAddNonAC.setBounds(150,220,210,30);
       panel2.add(btnAddNonAC);
       btnAddNonAC.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ae){
                    NonAcademicCourse();

                }
            });
       
       //label of courseLeader
       nacCourseLeader = new JLabel("Course Leader : ");
       nacCourseLeader.setBounds(10,270,230,30);
       panel2.add(nacCourseLeader);
       
       //textField of course Leader
       textNacCourseLeader = new JTextField();
       textNacCourseLeader.setBounds(150,270,230,30);
       panel2.add(textNacCourseLeader);
       
       //label of instructor name
       nacInstructorName = new JLabel("Instructor Name : ");
       nacInstructorName.setBounds(10,310,230,30);
       panel2.add(nacInstructorName);
       
       //textfield of instructor name 
       textNacInstructor = new JTextField();
       textNacInstructor.setBounds(150,310,230,30);
       panel2.add(textNacInstructor);
       
       //label of starting date
       nacStartDate = new JLabel("Starting Date : ");
       nacStartDate.setBounds(10,350,230,30);
       panel2.add(nacStartDate);
       
       //textField of starting date
       textNacStart = new JTextField();
       textNacStart.setBounds(150,350,230,30);
       panel2.add(textNacStart);
       
       //label of completion date
       nacCompletion = new JLabel("Completion Date :");
       nacCompletion.setBounds(10,390,230,30);
       panel2.add(nacCompletion);
       
       //textField of Completion date
       textNacCompletion = new JTextField();
       textNacCompletion.setBounds(150,390,230,30);
       panel2.add(textNacCompletion);
       
       //label of exam date
       nacExam = new JLabel("Exam Date : ");
       nacExam.setBounds(10,430,230,30);
       panel2.add(nacExam);
       
       //textField of exam date
       textNacExam = new JTextField();
       textNacExam.setBounds(150,430,230,30);
       panel2.add(textNacExam);
       
       //button of register 
       btnNacRegister = new JButton("Register");
       btnNacRegister.setBounds(150,470,230,30);
       panel2.add(btnNacRegister);
        btnNacRegister.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                nacRegister();
            }
        });
      
       //button of remove
       btnNacRemove = new JButton("Remove");
       btnNacRemove.setBounds(390,470,230,30);
       panel2.add(btnNacRemove);
       btnNacRemove.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent ae){
               nacRemove();
            }
       });
       
       //button of display
       btnNacDisplay = new JButton("Display");
       btnNacDisplay.setBounds(150,530,230,30);
       panel2.add(btnNacDisplay);
       btnNacDisplay.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent ae){
               nacDisplay();
            }
       });
       
       //button of clear
       btnNacClear = new JButton("Clear");
       btnNacClear.setBounds(390,530,230,30);
       panel2.add(btnNacClear);
       btnNacClear.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent ae){
               nacClear();
            }
            
    
       });
    }
            
     public void NonAcademicCourse(){
        int Duration;
        String nacCourseID = textNacCourseID.getText();
        String nacCourseName = textNacCourseName.getText();
        String nacDuration = textNacDuration.getText();
        String nacPrerequisite = textNacPrerequisite.getText();
        
        if(nacCourseID.trim().equals("")|| nacCourseName.trim().equals("")|| nacDuration.trim().equals("") || 
         nacPrerequisite.trim().equals("")){
            JOptionPane.showMessageDialog(window, "Some forms are unfilled so, please fill all the forms -_-", "Error", 0);   
        }
        else{
            try{
                Duration = Integer.parseInt(nacDuration);
            }
            catch(NumberFormatException nfe){
                JOptionPane.showMessageDialog(window, "Please enter data in correct format(-_-)", "Error message", JOptionPane.ERROR_MESSAGE);
                return;
            }
            for(course c:list){
                if(c instanceof NonAcademicCourse){
                    NonAcademicCourse nac = (NonAcademicCourse) c;
                    if(nac.getCourseID() == nacCourseID){
                        JOptionPane.showMessageDialog(window, "Course ID already added(o_o)", "Error",0);
                        return;
                    }
                }
            }
            NonAcademicCourse nacList = new NonAcademicCourse(nacCourseID, nacCourseName, Duration, nacPrerequisite);
            list.add(nacList);
            JOptionPane.showMessageDialog(window,"Non Academic Course is added successfully(^_^)","Info",1);
        }
    }
    
    public void nacRegister(){
        String nacCourseID = textNacCourseID.getText();
        String nacCourseLeader = textNacCourseLeader.getText();
        String nacInstructor = textNacInstructor.getText();
        String nacStartDate = textNacStart.getText();
        String nacCompletion = textNacCompletion.getText();
        String nacExam = textNacExam.getText();
          if(nacCourseID.trim().equals("") || nacCourseLeader.trim().equals("") || nacInstructor.trim().equals("") || nacStartDate.trim().equals("")|| 
          nacCompletion.trim().equals("") || nacExam.trim().equals(" ")){
            JOptionPane.showMessageDialog(window,"Some forms are unfilled so, please fill all the forms -_-","Error",0);
          }
          else{
            boolean isRegistered = false;
            for(course c : list){
                
                if(c instanceof NonAcademicCourse){
                    NonAcademicCourse nac = (NonAcademicCourse) c;
                    if(nac.getCourseID()== nacCourseID){
                        isRegistered = true;
                        if(nac.isRegistered == true)
                            JOptionPane.showMessageDialog(window,"This course is already registered (0_0)","Error",0);
                        }
                        else{
                            nac.Register(nacCourseLeader,nacInstructor, nacStartDate, nacCompletion,nacExam );
                            JOptionPane.showMessageDialog(window,"Non Academic Course Registered sucessfully (^~^)","Course Registered",1);
                            break;
                        }
                        if (isRegistered == false){
                        JOptionPane.showMessageDialog(window, " Course ID is not added, add the CourseID first" ,"Error",0);
                    }
                    }
            }
        }
    }
    
    
    
     public void nacRemove(){
        String nacCourseID = JOptionPane.showInputDialog(window,"Enter course ID (0_0)","Removed",3);
        boolean isRemoved = false;
        for(course c: list){
                if(c.getCourseID().equals(nacCourseID)){
                    if(c instanceof NonAcademicCourse){
                        NonAcademicCourse nac = (NonAcademicCourse) c;
                        if(nac.getIsRemoved() == false){
                        nac.Removed();
                        JOptionPane.showMessageDialog(window," Non Academic Course has been removed", "Removed", 1);
                        System.out.println("Non Academic Course has been removed");
                    }
                }else{
                    if(c.getCourseID().equals(nacCourseID)){
                        JOptionPane.showMessageDialog(window,"Non Academic course has already been removed","Removed",0);
                        break;
                    }
                }
            }
        }
    }
    
     public void nacDisplay(){
        boolean isRegistered = false;
        for(course c: list){
            if(c instanceof NonAcademicCourse){
                NonAcademicCourse nac = (NonAcademicCourse) c;
                isRegistered = true;
                nac.display();
            }
        }
        if(isRegistered == false){
            JOptionPane.showMessageDialog(window,"CourseID is not added yet(0_0)","Error",0);
        }
    }
    
    public void nacClear(){
        int x = JOptionPane.showConfirmDialog(window, "Do you want to clear all the informations of Non Academic Course?", "info", JOptionPane.YES_NO_OPTION);
        if (x == JOptionPane.YES_OPTION){
            JOptionPane.showMessageDialog(window, "Cleared", "info", (1));
            textNacCourseID.setText(null);
            textNacCourseName.setText(null);
            textNacDuration.setText(null);
            textNacPrerequisite.setText(null);
            textNacCourseLeader.setText(null);
            textNacInstructor.setText(null);
            textNacStart.setText(null);
            textNacCompletion.setText(null);
            textNacExam.setText(null);
        }
    }


    public static void main(String [] args){
        new INGCollege().window.setVisible(true);
    }
}