
/**
 * Write a description of class d here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class NonAcademicCourse extends course
{
    // instance variables - replace the example below with your own
    private String InstructorName;
    private String Prerequisite;
    private String ExamDate;
    private String StartDate;
    private String CompletionDate;
    private int Duration;
    public boolean isRegistered;
    public boolean isRemoved;
   //method of creating superclass constructor
   public NonAcademicCourse(String CourseID, String CourseName, int Duration,String Prerequisite)
    {
        // initialise instance variables
        super(CourseID, CourseName, Duration);
        this.isRemoved = false;
        this.ExamDate = "";
        this.Prerequisite = Prerequisite;
        this.StartDate = "";
        this.CompletionDate = "";
        this.isRegistered = false;
    }
    //creating a get method of attributes
    public String getInstructorName(){
        return InstructorName;
    }
    
    public String getStartDate(){
        return StartDate;
    }
    
    public String getCompletionDate (){
        return CompletionDate;
    }
    
    public String getExamDate(){
        return ExamDate;
    }
    
    public String getPrerequisite(){
        return Prerequisite;
    }
    
    public boolean getIsRegistered() {
        return isRegistered;
    }
    
    public boolean getIsRemoved(){
        return isRemoved;
    }
    //creating set method
    public void setInstructorName(String InstructorName){
        this.InstructorName = InstructorName;
        if(isRegistered == false){
            System.out.println("Instructor Name" +this.InstructorName);
        }
        else{
            System.out.println("NonAcadamicCourse is alredy registered. The user indicating that it's not possible to change");
        }
    }
    //method of registered of NonAcadamicCourse
    public void Register(String CourseLeader,  String InstructorName, String StartDate,String CompletionDate,String ExamDate){
        if(getIsRegistered() == true){
           System.out.println("Name of Instructor name: "+ getInstructorName());
           System.out.println("Starting date of course :" + getStartDate());
            System.out.println("completion date :" + getCompletionDate());
            System.out.println("Exam date :" + getExamDate());
            System.out.println("Non Academic Course is already registered");
        
        }
        else{
            super.setCourseLeader(CourseLeader);
            this.InstructorName = InstructorName;
            this.StartDate = StartDate;
            this.CompletionDate = CompletionDate;
            this.ExamDate = ExamDate;
            isRegistered = true;
            isRemoved = false;
        }
    }

    
    //Creating removed method
    public void Removed(){
        if(getIsRemoved() == true){
            System.out.println("NonAcademicCourse is already removed");
        }
        else{
            this.InstructorName = "";
            this.StartDate = "";
            this.CompletionDate = "";
            this.ExamDate = "";
            this.isRegistered = false;
            this.isRemoved = true;
        }
    }

    //creating a display method
    public void display(){
        super.Display();
        if(isRegistered == true){
            System.out.println("Prerequisite :" + getPrerequisite());
            System.out.println("Name of Instructor :" + getInstructorName());
            System.out.println("Starting Date :" + getStartDate());
            System.out.println("Completion Date :" + getCompletionDate());
            System.out.println("Exam Date :" + getExamDate());
    
        }
    }
}