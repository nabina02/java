
/**
 * Write a description of class s here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AcademicCourse extends course{
    // instance variables - replace the example below with your own
    private String LecturerName;
    private String Level;
    private String Credit;
    private String StartingDate;
    private String CompletionDate;
    private int NumberOfAssessments;
    public boolean isRegistered;
    //method of creating superclass constructor 
    public AcademicCourse(String CourseID, String CourseName, int Duration, String Level, String Credit, int NumberOfAssessments)
    {
        // initialise instance variables
        super(CourseID, CourseName, Duration);
        this.Level = Level;
        this.Credit = Credit;
        this.NumberOfAssessments = NumberOfAssessments;
        this.LecturerName = "";
        this.StartingDate = "";
        this.CompletionDate = "";
        this.isRegistered = false;
    }
    //creating a get method of attributes
    public String getLecturerName(){
        return LecturerName;
    }
    
    public String getLevel(){
        return Level;
    }
    
    public String getCredit(){
        return Credit;
    }
    
    public String getStartingDate(){
        return StartingDate;
    }
    
    public String getCompletionDate(){
        return CompletionDate;
    }
    
    public int getNumberOfAssessments() {
        return NumberOfAssessments;
    }
    
    public boolean getIsRegistered(){
        return isRegistered;
    }
    //creating a set method of attributes
    public void setLecturerName(String LecturerName){
        this.LecturerName = LecturerName;
    }
    
    public void setNumberOfAssessments(int NumberOfAssessments){
        this.NumberOfAssessments = NumberOfAssessments;
    }
    //registration method creating
    public void Registered(String CourseLeader, String LecturerName, String StartingDate, String Completion){
        if(getIsRegistered() == true){
            System.out.println("Name of Lecturer :" + getLecturerName());
            System.out.println("Starting date of course :" + getStartingDate());
            System.out.println("Completion date :" + getCompletionDate());
            System.out.println("Academic Course is already registered");
        }
        else{
            super.setCourseLeader(CourseLeader);
            this.LecturerName = LecturerName;
            this.StartingDate = StartingDate;
            this.CompletionDate = CompletionDate;
            this.isRegistered = true;
            System.out.println("This Course has been Registered Successfully");
        }
    }
    
    //ceating a display method
    public void Display(){
        super.Display();
        if (isRegistered == true){
           System.out.println("Number of Assessment :" + getNumberOfAssessments());
           System.out.println("Name of Lecturer :" + getLecturerName());
           System.out.println("Level is :" + getLevel());
           System.out.println("Credit of course :" + getCredit());
           System.out.println("starting date :" + getStartingDate());
           System.out.println("Completion date :" + getCompletionDate());
      
        }
    }
}